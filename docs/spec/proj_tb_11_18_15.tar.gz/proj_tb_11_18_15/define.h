`define activehigh 1
`define procline posedge clk
`define proclineg posedge clk
`define proclineSlow posedge clkSlow
`define proclineFast posedge clkFast
`define proclinerclk posedge rclk
`define proclinewclk posedge wclk
`define grsttype "synch"
